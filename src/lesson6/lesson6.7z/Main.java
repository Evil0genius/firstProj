package lesson6;

//import static lesson6.SaperUtils.fillMines;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome");
        int[][] field = new int[9][9];
        boolean[][] mask = new boolean[9][9];
        saperUtils.fillMines(field);
        saperUtils.insertNumAroundMines(field);
        saperUtils.printField(field, mask);



    }
}
