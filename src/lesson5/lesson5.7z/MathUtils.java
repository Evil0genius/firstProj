package lesson5;

import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;
import static lesson5.ScannerUtils.inputVar;


public class MathUtils {

    public static String getChoose(String figure, String action) {
        if (figure.equals(inputVar[0]) || figure.equalsIgnoreCase("круг")) {
            out.println("Введите радиус:");
            double radius = getParameter();
            if (action.equalsIgnoreCase("площадь")) {
                return ("Площадь круга: " + radius * Math.PI);   //radius*3.14
            } else return ("Периметр круга: " + radius * Math.PI * 2);
        } else if (figure.equals(inputVar[1]) || figure.equalsIgnoreCase("квадрат")) {
            out.println("Введите сторону:");
            double side = getParameter();
            if (action.equalsIgnoreCase("площадь")) {
                return ("Площадь квадрата: " + side * 2);
            } else return ("Периметр квадрата: " + side * 4);
        } else if (figure.equals(inputVar[2]) || figure.equalsIgnoreCase("треугольник")) {
            out.println("Введите сторону А:");
            double a = getParameter();
            out.println("Введите сторону B:");
            double b = getParameter();
            out.println("Введите сторону С:");
            double c = getParameter();
            if (action.equalsIgnoreCase("площадь")) {
                double p = (a + b + c) / 2;
                return ("Площадь треугольника: " + Math.sqrt(p * (p - a) * (p - b) * (p - c)));
            } else return "Периметр треугольника: " + (a + b + c);
        } else if (figure.equals(inputVar[3]) || figure.equalsIgnoreCase("овал")) {
            out.println("Введите малую полуось:");
            double a = getParameter();
            out.println("Введите большую полуось:");
            double b = getParameter();
            if (action.equalsIgnoreCase("площадь")) {
                return ("Площадь овала: " + a * b * Math.PI);
            } else return ("Периметр овала: " + 4 * (Math.PI * a * b + (a - b) * (a - b)) / (a + b));
        } else if (figure.equals(inputVar[4]) || figure.equalsIgnoreCase("трапеция")) {
            out.println("Введите сторону А:");
            double a = getParameter();
            out.println("Введите сторону B:");
            double b = getParameter();
            if (action.equalsIgnoreCase("площадь")) {
                out.println("Введите высоту:");
                double h = getParameter();
                return ("Площадь трапеции: " + (a + b) * h / 2);
            } else {
                out.println("Введите сторону С:");
                double c = getParameter();
                out.println("Введите сторону D:");
                double d = getParameter();
                return ("Периметр трапеции: " + (a + b + c + d));
            }
        } else return null;
    }


    private static double getParameter() {

        Scanner scanner = new Scanner(in);
        String inputCheck = scanner.next();
        if (isNumeric(inputCheck)) {
            double inputDouble = Double.parseDouble(inputCheck);
            if (inputDouble > 0) {
                return inputDouble;
            } else {
                out.println("Отрицательное число или ноль");
                return getParameter();
            }
        } else {
            out.println("Вы ввели не число");
            return getParameter();
        }
    }

    private static boolean isNumeric(String inputCheck) {
        try {
            Double.parseDouble(inputCheck);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
